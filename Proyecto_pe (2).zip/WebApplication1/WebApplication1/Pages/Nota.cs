﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1
{
    public class Nota
    {
        public string Nombre { get; set; }
        public string Materia { get; set; }
        public double Parcial1 { get; set; }
        public double Parcial2 { get; set; }
        public double ExamenFinal { get; set; }
    }

}
